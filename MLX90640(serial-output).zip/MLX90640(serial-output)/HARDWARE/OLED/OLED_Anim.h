#ifndef __OLED_ANIM_H__
#define __OLED_ANIM_H__
void RightComeOut_Refresh(void);

void RightToLeft_Clear(void);
void Screensaver(void);//չʾ����
void test2(void);
#endif






