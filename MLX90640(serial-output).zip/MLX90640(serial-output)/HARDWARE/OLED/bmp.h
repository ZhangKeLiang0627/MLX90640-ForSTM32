#ifndef __BMP_H
#define __BMP_H
extern unsigned char BMP1[];
extern unsigned char BMP2[][512];
#endif


