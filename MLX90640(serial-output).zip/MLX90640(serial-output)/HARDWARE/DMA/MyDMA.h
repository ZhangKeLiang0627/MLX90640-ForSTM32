#ifndef __MYDMA_H__
#define __MYDMA_H__
#include "sys.h"
	
void DMA2_Init(u16 cndtr);


#endif

